/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author LabP1010
 */
public class Mavenproject1 {

    public static void main(String[] args) {
       Usuario usuarionuevo1 = new Usuario("admin","admin10");
       Usuario usuarionuevo2 = new Usuario("arielr","arielr10");
       Usuario usuarionuevo3 = new Usuario("pabloD","pablo123");

       ListaUsuarios.registrar(usuarionuevo1);
       ListaUsuarios.registrar(usuarionuevo2);
       ListaUsuarios.registrar(usuarionuevo3);
       
        Acceso jfacceso = new Acceso();
       jfacceso.setVisible(true);
    }
    
    
}
