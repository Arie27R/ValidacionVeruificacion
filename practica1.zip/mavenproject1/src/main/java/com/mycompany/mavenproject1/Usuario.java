/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Vector;

/**
 *
 * @author LabP1010
 */
public class Usuario {
    private String nickname;
    private String password;

    public Usuario(String nickname, String password){
        this.nickname = nickname;
        this.password = password;
    }
    
    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public static Vector mostrar(){
    return ListaUsuarios.mostrar();
    }
    
    public static int verificarLogueo(String usuario, String password){
        Vector lista = mostrar();
        Usuario obj;
        
        for(int i = 0; i < lista.size(); i++){
            obj = (Usuario) lista.elementAt(i);
            //En este lugar se presenta un error y un defecto, ya que no se compara la contraseña en ningun momento. 
            if(obj.getNickname().equalsIgnoreCase(usuario)){
                return i;
            }
        }
        return -1;
    }
    
}
