/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Vector;

/**
 *
 * @author LabP1010
 */
public class ListaUsuarios {
    private static Vector<Usuario> datos = new Vector<Usuario>();
    public static Vector mostrar(){
    return datos;
    }
    
    public static void registrar(Usuario usuario){
    datos.addElement(usuario);
    }
}
